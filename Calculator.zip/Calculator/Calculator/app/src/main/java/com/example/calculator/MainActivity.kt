package com.example.calculator
import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import android.view.View
import android.widget.Button
import android.widget.EditText
import kotlinx.android.synthetic.main.activity_main.*
class MainActivity : AppCompatActivity() {
    var num = true
    var oldNumber = ""
    var operator = "+"
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)
    }
    fun eventNumbers(view: android.view.View) {
        if(num)
            editText.setText("")
        num = false
        var click : String = editText.text.toString()
        var select : Button = view as Button
        when(select.id){
            One.id -> {click+="1"}
            Two.id -> {click+="2"}
            Three.id -> {click+="3"}
            Four.id -> {click+="4"}
            Five.id -> {click+="5"}
            Six.id -> {click+="6"}
            Seven.id -> {click+="7"}
            Eight.id -> {click+="8"}
            Nine.id -> {click+="9"}
            Zero.id -> {click+="0"}
            Dot.id -> {click+="."}
            Sign.id -> {click = "-$click"}
        }
        editText.setText(click)
    }
    fun eventOperators(view: android.view.View) {
        num = true
        oldNumber = editText.text.toString()
        var select = view as Button
        when(select.id){
            Sum.id -> {operator = "+"}
            Difference.id -> {operator = "-"}
            Product.id -> {operator = "*"}
            Division.id -> {operator = "/"}
            Mod.id -> {operator = "%"}
        }
    }
    fun calculations(view: android.view.View) {
        var newNumber : String = editText.text.toString()
        var result = 0.0
        when(operator){
            "+" -> {result = oldNumber.toDouble() + newNumber.toDouble()}
            "-" -> {result = oldNumber.toDouble() - newNumber.toDouble()}
            "*" -> {result = oldNumber.toDouble() * newNumber.toDouble()}
            "/" -> {result = oldNumber.toDouble() / newNumber.toDouble()}
            "%" -> {result = oldNumber.toDouble() % newNumber.toDouble()}
        }
        editText.setText(result.toString())
    }
    fun Erase(view: android.view.View) {
        editText.setText("0")
        num = true
    }
}
